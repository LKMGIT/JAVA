package August.day18.Task;

import java.util.List;

public interface Board_interface {
    public void create(Board board);
    public void read();
    public void clear();
}
