package August.day18.Task;

import java.util.ArrayList;
import java.util.List;

public class BoardManager implements Board_interface{
    private List<Board> boards = new ArrayList<Board>();

    @Override
    public void create(Board board) {
        boards.add(board);
    }

    @Override
    public void read() {
        for (Board board : boards) {
            System.out.println(board);
        }
    }

    @Override
    public void clear() {
        boards.clear();
    }
}
